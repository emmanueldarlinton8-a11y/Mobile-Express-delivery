import { BRAND } from "./firebase-config.js";
import { t, locale } from "./i18n.js";

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];

export const STATUSES = [
  { key: "received", label: "Order received" },
  { key: "packed", label: "Packed" },
  { key: "out", label: "Out for delivery" },
  { key: "delivered", label: "Delivered" },
];
export const STATUS_LABEL = Object.fromEntries(
  [...STATUSES, { key: "cancelled", label: "Cancelled" }].map((s) => [s.key, s.label])
);
export const PAY = { unpaid: "Unpaid", part: "Part paid", paid: "Paid in full" };

export const money = (n) => BRAND.currency + Number(n || 0).toLocaleString(locale(), { maximumFractionDigits: 2 });

export function makeCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 32 characters, no look-alikes
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  let s = "";
  for (const b of bytes) s += alphabet[b % 32];
  return "MEX-" + s;
}

export function shortName(full) {
  const parts = String(full || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length < 2) return parts[0] || "Customer";
  return parts[0] + " " + parts[parts.length - 1][0].toUpperCase() + ".";
}

export function waNumber(phone) {
  let d = String(phone || "").replace(/\D/g, "");
  if (d.length === 8) d = BRAND.countryCode + d; // Guatemalan local numbers have 8 digits
  return d;
}

export function ago(ts) {
  if (!ts) return t("ago.never");
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return t("ago.s", { n: s });
  const m = Math.round(s / 60);
  if (m < 60) return t("ago.m", { n: m });
  const h = Math.round(m / 60);
  if (h < 24) return t("ago.h", { n: h });
  return t("ago.d", { n: Math.round(h / 24) });
}

export function fmtTime(ts) {
  return new Date(ts).toLocaleString(locale(), { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
}

export function km(a, b) {
  const R = 6371, rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function distText(d) {
  return d < 1 ? Math.round(d * 1000) + " m" : d.toFixed(1) + " km";
}

export function etaText(d) {
  const mins = Math.max(1, Math.round((d / 25) * 60)); // assumes about 25 km/h in town
  return mins < 60 ? t("eta.min", { n: mins }) : t("eta.hrmin", { h: Math.floor(mins / 60), m: mins % 60 });
}

export function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

export const dotIcon = (cls = "") => L.divIcon({ className: "", html: `<span class="pin ${cls}"></span>`, iconSize: [22, 22], iconAnchor: [11, 11] });

export function makeMap(el, center, zoom = 13) {
  const map = L.map(el, { zoomControl: true }).setView(center || BRAND.center, zoom);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
    maxZoom: 19,
    subdomains: "abcd",
    attribution: "&copy; OpenStreetMap contributors &copy; CARTO",
  }).addTo(map);
  return map;
}

export function toast(msg) {
  let t = $("#toast");
  if (!t) { t = document.createElement("div"); t.id = "toast"; t.setAttribute("role", "status"); document.body.append(t); }
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 2800);
}

export function brandHtml() {
  return `<div class="brand"><b>Mobile Express<i>GT</i></b><span>${esc(BRAND.tagline)}</span></div>`;
}
