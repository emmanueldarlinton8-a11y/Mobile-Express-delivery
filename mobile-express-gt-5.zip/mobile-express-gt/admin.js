import { init } from "./db.js";
import { BRAND } from "./firebase-config.js";
import { $, STATUS_LABEL, PAY, money, ago, esc, makeCode, shortName, waNumber, dotIcon, makeMap, toast } from "./common.js";

const api = await init();
if (api.mode === "demo") $("#demo").hidden = false;

let orders = [], cur = null, started = false;
let emap = null, epin = null, dest = null;
let fleet = null, fleetMarkers = {}, liveSubs = {}, liveData = {}, fleetFitted = false;

/* ---------- auth ---------- */
api.onAuth((user, role) => {
  const show = (id, on) => ($(id).hidden = !on);
  if (!user) { show("#login", true); show("#nav", false); show("#orders", false); show("#live", false); return; }
  if (role !== "admin") {
    show("#login", true); show("#nav", false);
    const m = $("#lmsg"); m.hidden = false; m.textContent = "This account is not set up as an admin. See README.md, step 4.";
    return;
  }
  show("#login", false); show("#nav", true); setTab("orders");
  if (!started) { started = true; api.watchOrders((list) => { orders = list; renderList(); syncFleet(); }); }
});

$("#lf").addEventListener("submit", async (e) => {
  e.preventDefault();
  const m = $("#lmsg"); m.hidden = true;
  try { await api.login($("#em").value.trim(), $("#pw").value); }
  catch (err) { m.hidden = false; m.textContent = "Could not log in. Check your email and password."; }
});
$("#logout").addEventListener("click", () => api.logout());

/* ---------- tabs ---------- */
function setTab(t) {
  $("#orders").hidden = t !== "orders"; $("#live").hidden = t !== "live";
  $("#t-orders").classList.toggle("on", t === "orders"); $("#t-live").classList.toggle("on", t === "live");
  if (t === "live") {
    if (!fleet) fleet = makeMap("fleet", BRAND.center, 11);
    setTimeout(() => { fleet.invalidateSize(); syncFleet(); }, 50);
  }
}
$("#t-orders").addEventListener("click", () => setTab("orders"));
$("#t-live").addEventListener("click", () => setTab("live"));

/* ---------- order list ---------- */
function renderList() {
  const q = $("#q").value.trim().toLowerCase(), f = $("#flt").value;
  const rows = orders.filter((o) => (!f || o.status === f) && (!q || (o.code + " " + o.recipient).toLowerCase().includes(q)));
  $("#olist").innerHTML = rows.length
    ? rows.map((o) => `<li><button data-c="${esc(o.code)}" class="${cur && cur.code === o.code ? "sel" : ""}">
        <span class="row" style="justify-content:space-between"><b>${esc(o.code)}</b><span class="pill ${o.status}">${STATUS_LABEL[o.status] || ""}</span></span>
        <span>${esc(o.recipient)} &middot; ${money(o.total)}</span>
        <span class="row"><span class="pill ${o.payment}">${PAY[o.payment] || ""}</span><span class="mut small">${ago(o.updatedAt)}</span></span>
      </button></li>`).join("")
    : `<li class="mut">No orders yet. Tap + New to add one.</li>`;
}
$("#olist").addEventListener("click", (e) => { const b = e.target.closest("button[data-c]"); if (b) openEditor(b.dataset.c); });
$("#q").addEventListener("input", renderList);
$("#flt").addEventListener("change", renderList);
$("#new").addEventListener("click", () => openEditor(null));

/* ---------- editor ---------- */
function ensureEditorMap() {
  if (emap) return;
  emap = makeMap("emap", BRAND.center, 12);
  emap.on("click", (e) => setDest({ lat: +e.latlng.lat.toFixed(6), lng: +e.latlng.lng.toFixed(6) }));
}
function setDest(d) {
  dest = d;
  if (epin) { epin.remove(); epin = null; }
  if (d) { epin = L.marker([d.lat, d.lng], { icon: dotIcon("dest") }).addTo(emap); emap.setView([d.lat, d.lng], Math.max(emap.getZoom(), 14)); }
}

async function openEditor(code) {
  const prev = code ? orders.find((o) => o.code === code) : null;
  const contact = prev ? await api.getContact(code) : {};
  cur = prev ? { ...prev } : { code: makeCode(), status: "received", isNew: true };
  $("#editor").hidden = false;
  ensureEditorMap();
  setTimeout(() => emap.invalidateSize(), 50);
  $("#e-code").textContent = cur.code;
  $("#f-name").value = contact.fullName || (prev ? prev.recipient : "");
  $("#f-phone").value = contact.phone || "";
  $("#f-addr").value = contact.address || "";
  $("#f-items").value = cur.items || "";
  $("#f-total").value = cur.total ?? "";
  $("#f-paid").value = cur.paid ?? "";
  $("#f-status").value = cur.status;
  $("#f-rider").value = cur.rider || "";
  $("#f-eta").value = cur.eta || "";
  $("#f-area").value = cur.area || "";
  $("#f-note").value = "";
  $("#f-dlabel").value = cur.dest?.label || "";
  setDest(cur.dest ? { lat: cur.dest.lat, lng: cur.dest.lng } : null);
  if (!cur.dest) emap.setView(BRAND.center, 12);
  $("#del").hidden = !!cur.isNew;
  $("#del").textContent = "Delete order";
  refreshDerived();
  renderList();
  $("#editor").scrollIntoView({ behavior: "smooth", block: "start" });
}

function payState(total, paid) { return total > 0 && paid >= total ? "paid" : paid > 0 ? "part" : "unpaid"; }

function refreshDerived() {
  if (!cur) return;
  const total = +$("#f-total").value || 0, paid = +$("#f-paid").value || 0;
  $("#f-bal").value = money(Math.max(0, total - paid));
  const ps = payState(total, paid), st = $("#f-status").value;
  $("#e-pay").className = "pill " + ps; $("#e-pay").textContent = PAY[ps];
  $("#e-status").className = "pill " + st; $("#e-status").textContent = STATUS_LABEL[st];
  $("#warn").hidden = !(st === "out" && ps === "unpaid");
  const link = new URL("index.html?c=" + cur.code, location.href).href;
  $("#e-link").value = link;
  const name = $("#f-name").value.trim().split(/\s+/)[0] || "";
  const msg = `Hello ${name}, track your Mobile Express GT order live here: ${link}`;
  const num = waNumber($("#f-phone").value);
  $("#wa").href = (num ? "https://wa.me/" + num : "https://wa.me/") + "?text=" + encodeURIComponent(msg);
}
for (const id of ["#f-total", "#f-paid", "#f-status", "#f-name", "#f-phone"]) $(id).addEventListener("input", refreshDerived);

$("#copy").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText($("#e-link").value); toast("Link copied"); }
  catch (e) { $("#e-link").select(); toast("Press copy on your keyboard"); }
});
$("#usegps").addEventListener("click", () => {
  if (!navigator.geolocation) return toast("Location is not available on this device");
  navigator.geolocation.getCurrentPosition(
    (p) => setDest({ lat: +p.coords.latitude.toFixed(6), lng: +p.coords.longitude.toFixed(6) }),
    () => toast("Could not get your location"), { enableHighAccuracy: true, timeout: 10000 });
});
$("#clrpin").addEventListener("click", () => setDest(null));

$("#editor").addEventListener("submit", async (e) => {
  e.preventDefault();
  const code = cur.code;
  const prev = orders.find((o) => o.code === code);
  const total = +$("#f-total").value || 0, paid = +$("#f-paid").value || 0;
  const status = $("#f-status").value, note = $("#f-note").value.trim();
  const timeline = prev?.timeline ? [...prev.timeline] : [];
  if (!prev) timeline.push({ status, note: note || "Order created", at: Date.now() });
  else if (prev.status !== status || note) timeline.push({ status, note: note || STATUS_LABEL[status], at: Date.now() });
  const fullName = $("#f-name").value.trim();
  const pub = {
    code, recipient: shortName(fullName), items: $("#f-items").value.trim(), status, total, paid, payment: payState(total, paid),
    dest: dest ? { lat: dest.lat, lng: dest.lng, label: $("#f-dlabel").value.trim() } : null,
    area: $("#f-area").value.trim(), eta: $("#f-eta").value.trim(), rider: $("#f-rider").value.trim(),
    timeline, createdAt: prev?.createdAt || Date.now(), updatedAt: Date.now(),
  };
  const contact = { fullName, phone: $("#f-phone").value.trim(), address: $("#f-addr").value.trim() };
  $("#save").disabled = true;
  try {
    await api.saveOrder(code, pub, contact);
    if (status === "delivered" || status === "cancelled") await api.clearLive(code);
    cur.isNew = false; $("#del").hidden = false;
    toast("Order saved");
  } catch (err) { toast("Could not save. Check your connection and admin access."); }
  $("#save").disabled = false;
});

let delArmed = false;
$("#del").addEventListener("click", async () => {
  if (!delArmed) {
    delArmed = true; $("#del").textContent = "Tap again to delete";
    setTimeout(() => { delArmed = false; $("#del").textContent = "Delete order"; }, 4000);
    return;
  }
  delArmed = false;
  try { await api.deleteOrder(cur.code); cur = null; $("#editor").hidden = true; toast("Order deleted"); }
  catch (err) { toast("Could not delete"); }
});

/* ---------- live map of all active deliveries ---------- */
function syncFleet() {
  if (!fleet) return;
  const active = orders.filter((o) => o.status === "out");
  const keep = new Set(active.map((o) => o.code));
  for (const c of Object.keys(liveSubs)) {
    if (!keep.has(c)) { liveSubs[c](); delete liveSubs[c]; delete liveData[c]; if (fleetMarkers[c]) { fleetMarkers[c].remove(); delete fleetMarkers[c]; } }
  }
  for (const o of active) {
    if (liveSubs[o.code]) continue;
    liveSubs[o.code] = api.watchLive(o.code, (l) => { liveData[o.code] = l; drawFleet(); });
  }
  drawFleet();
}
function drawFleet() {
  const active = orders.filter((o) => o.status === "out");
  const pts = [];
  let withGps = 0;
  for (const o of active) {
    const l = liveData[o.code];
    if (!l || !isFinite(l.lat)) { if (fleetMarkers[o.code]) { fleetMarkers[o.code].remove(); delete fleetMarkers[o.code]; } continue; }
    withGps++;
    const tip = `${esc(o.recipient)} (${esc(o.code)})<br>${esc(o.rider || "Rider")} &middot; ${ago(l.t)}`;
    if (!fleetMarkers[o.code]) fleetMarkers[o.code] = L.marker([l.lat, l.lng], { icon: dotIcon() }).addTo(fleet).bindTooltip(tip);
    else { fleetMarkers[o.code].setLatLng([l.lat, l.lng]); fleetMarkers[o.code].setTooltipContent(tip); }
    pts.push([l.lat, l.lng]);
  }
  if (pts.length && !fleetFitted) { fleet.fitBounds(pts, { padding: [50, 50], maxZoom: 15 }); fleetFitted = true; }
  $("#fleetinfo").textContent = active.length
    ? `${active.length} order${active.length > 1 ? "s" : ""} out for delivery, ${withGps} sharing live location.`
    : "No orders are out for delivery right now.";
}
setInterval(() => { if (!$("#live").hidden) drawFleet(); }, 20000);
