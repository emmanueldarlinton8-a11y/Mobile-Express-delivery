// Paste your Firebase web app config here (see README.md, step 2).
// While this is null, the site runs in DEMO MODE: data stays in this browser only.
//
// Example:
// export const firebaseConfig = {
//   apiKey: "...", authDomain: "...", projectId: "...",
//   storageBucket: "...", messagingSenderId: "...", appId: "..."
// };
export const firebaseConfig = null;

export const BRAND = {
  name: "Mobile Express GT",
  tagline: "Technology at your fingertips",
  // Maps open on Guatemala City when nothing else is known. Once an order has a
  // drop-off pin or a rider is sharing GPS, every map moves to those real locations.
  center: [14.6349, -90.5069],
  currency: "Q", // Guatemalan quetzal
  countryCode: "502", // used to build WhatsApp links from 8-digit local numbers
};
