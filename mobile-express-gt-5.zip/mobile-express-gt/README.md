# Mobile Express GT: delivery tracking

Three pages, one shared database:

- `index.html`: customers enter their tracking code and see goods, payment, status and the rider's live GPS on a map.
- `admin.html`: you add orders (recipient, goods, payment, drop-off pin), update status, and watch every rider on one live map.
- `rider.html`: riders log in, tick the orders they carry, and tap Start trip to share live GPS.

## Try it first (demo mode)

Open `index.html` through any local web server (for example `python3 -m http.server` in this folder, then visit `http://localhost:8000`). Data stays in that browser only.
Customer code to try: `MEX-DEMO2026`. Admin and rider pages accept any email and password in demo mode. On the rider page, use "Simulate a drive" to watch the dot move on the customer page in another tab.

## Go live (about 15 minutes, free tier)

1. Create a project at https://console.firebase.google.com.
2. Project settings > Your apps > Web app. Copy the config and paste it into `firebase-config.js` in place of `null`.
3. Build > Firestore Database > Create database. Then open the Rules tab, paste the contents of `firestore.rules`, and Publish.
4. Build > Authentication > Sign-in method > enable Email/Password. Under Users, add one account for yourself and one per rider. Copy each user's UID.
   In Firestore, create collection `staff`. For each person add a document whose ID is their UID with one field `role` (string): `admin` for you, `rider` for riders.
5. Host the folder over https (GPS only works on https). Easiest: Firebase Hosting (`firebase init hosting`, then `firebase deploy`) or drag the folder onto https://app.netlify.com/drop.
   Then add your site's domain in Authentication > Settings > Authorized domains.

## Daily use

1. Admin: tap + New, fill in the order, place the drop-off pin, Save, then Send on WhatsApp. The customer gets a link with their code already in it.
2. Rider: log in on their phone, tick the orders they are carrying, tap Start trip, keep the page open.
3. Customer: opens the link and watches the rider approach. Distance and arrival time are estimates from straight-line distance.
4. Admin or rider marks the order Delivered. Live tracking stops for that order.

## Notes

- Customers only see a shortened name (for example "Ada O."), goods, payment and status. Phone numbers and addresses are visible to staff only.
- The admin screen warns you if an order is set to Out for delivery with no payment recorded.
- Map tiles come from OpenStreetMap and CARTO, free for small shops. If traffic grows, switch to a paid tile provider in `common.js`.
- Maps open on Guatemala City only when nothing else is known. Once an order has a drop-off pin or a rider is sharing GPS, each map moves to those real locations, so it works anywhere. Change `BRAND.center` in `firebase-config.js` to start somewhere else.
- Currency is the quetzal (Q) and WhatsApp links add +502 to 8-digit numbers. Both are set in `firebase-config.js`.
- The customer page has a language selector (Español, English, Français, Português) and remembers each visitor's choice. To add a language, copy a block in `i18n.js`. Goods descriptions and notes you type yourself are shown exactly as written.
