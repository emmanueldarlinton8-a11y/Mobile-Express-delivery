import { init } from "./db.js";
import { BRAND } from "./firebase-config.js";
import { initLang, setLang, getLang, t, noteText, applyStatic, LANGS } from "./i18n.js";
import { $, STATUSES, money, ago, km, distText, etaText, esc, dotIcon, makeMap, fmtTime } from "./common.js";

const api = await init();
initLang();

let unsubs = [], order = null, live = null;
let map = null, riderM = null, destM = null, line = null, fitted = false;

/* ---------- language ---------- */
$("#lang").innerHTML = LANGS.map(([k, name]) => `<option value="${k}">${name}</option>`).join("");
$("#lang").value = getLang();
$("#lang").addEventListener("change", (e) => { setLang(e.target.value); relang(); });

function relang() {
  applyStatic();
  if (api.mode === "demo") { $("#demo").hidden = false; $("#demo").textContent = t("demo", { code: "MEX-DEMO2026" }); }
  // markers carry translated tooltips, so rebuild them
  if (riderM) { riderM.remove(); riderM = null; }
  if (destM) { destM.remove(); destM = null; }
  if ($("#msg").dataset.k) $("#msg").textContent = t($("#msg").dataset.k);
  if (order) render();
}

function msg(key) {
  const m = $("#msg");
  if (key) { m.dataset.k = key; m.textContent = t(key); } else { delete m.dataset.k; m.textContent = ""; }
}

/* ---------- tracking ---------- */
function stop() {
  unsubs.forEach((u) => u && u());
  unsubs = []; order = null; live = null; fitted = false;
  if (map) { map.remove(); map = null; riderM = destM = line = null; }
}

function start(raw) {
  const code = raw.trim().toUpperCase().replace(/\s+/g, "");
  if (!code) return;
  stop();
  $("#code").value = code;
  msg("msg.looking");
  $("#result").hidden = true;
  try { history.replaceState(null, "", "?c=" + encodeURIComponent(code)); } catch (e) { /* ignore */ }
  unsubs.push(api.watchOrder(code, (o) => {
    if (!o) { order = null; $("#result").hidden = true; msg("msg.notfound"); return; }
    order = o; msg(null); render();
  }));
  unsubs.push(api.watchLive(code, (l) => { live = l; if (order) { drawMap(); liveLine(); } }));
}

function render() {
  $("#result").hidden = false;
  $("#r-code").textContent = order.code;
  const st = $("#r-status");
  st.textContent = t("status." + order.status);
  st.className = "pill " + order.status;

  const idx = STATUSES.findIndex((s) => s.key === order.status);
  $("#steps").innerHTML = order.status === "cancelled"
    ? ""
    : STATUSES.map((s, i) => `<li class="${i <= idx ? "done" : ""} ${i === idx ? "now" : ""}">${t("status." + s.key)}</li>`).join("");

  const balance = Math.max(0, (order.total || 0) - (order.paid || 0));
  const rows = [
    ["k.recipient", esc(order.recipient)],
    ["k.goods", esc(order.items)],
    ["k.total", money(order.total)],
    ["k.paid", money(order.paid)],
    ["k.balance", balance ? money(balance) : t("k.none")],
    ["k.payment", `<span class="pill ${order.payment}">${t("pay." + order.payment)}</span>`],
    order.rider ? ["k.rider", esc(order.rider)] : null,
    order.area ? ["k.area", esc(order.area)] : null,
    order.eta ? ["k.expected", esc(order.eta)] : null,
  ].filter(Boolean);
  $("#details").innerHTML = rows.map(([k, v]) => `<dt>${t(k)}</dt><dd>${v}</dd>`).join("");

  $("#timeline").innerHTML = [...(order.timeline || [])].reverse()
    .map((x) => `<li><b>${esc(noteText(x.note || ""))}</b><span>${t("status." + x.status)} &middot; ${fmtTime(x.at)}</span></li>`)
    .join("");

  if (!map) {
    map = makeMap("map", order.dest ? [order.dest.lat, order.dest.lng] : BRAND.center);
    setTimeout(() => map.invalidateSize(), 50);
  }
  drawMap(); liveLine();
}

function drawMap() {
  if (!map || !order) return;
  const pts = [];
  const d = order.dest;
  if (d && isFinite(d.lat)) {
    if (!destM) destM = L.marker([d.lat, d.lng], { icon: dotIcon("dest") }).addTo(map).bindTooltip(t("map.dest"));
    else destM.setLatLng([d.lat, d.lng]);
    pts.push([d.lat, d.lng]);
  }
  const showRider = live && isFinite(live.lat) && order.status !== "delivered" && order.status !== "cancelled";
  if (showRider) {
    if (!riderM) riderM = L.marker([live.lat, live.lng], { icon: dotIcon() }).addTo(map).bindTooltip(t("map.rider"));
    else riderM.setLatLng([live.lat, live.lng]);
    pts.push([live.lat, live.lng]);
  } else if (riderM) { riderM.remove(); riderM = null; }

  if (line) { line.remove(); line = null; }
  if (showRider && d && isFinite(d.lat)) {
    line = L.polyline([[live.lat, live.lng], [d.lat, d.lng]], { color: "#37e3ff", weight: 3, dashArray: "6 8", opacity: 0.8 }).addTo(map);
  }
  if (pts.length && (!fitted || (showRider && !map.getBounds().pad(-0.1).contains([live.lat, live.lng])))) {
    map.fitBounds(pts, { padding: [44, 44], maxZoom: 16 });
    fitted = true;
  }
}

function liveLine() {
  if (!order) return;
  const el = $("#liveline");
  const s = order.status;
  if (s === "delivered") el.textContent = t("live.delivered");
  else if (s === "cancelled") el.textContent = t("live.cancelled");
  else if (s === "out") {
    if (live && isFinite(live.lat)) {
      if (order.dest && isFinite(order.dest.lat)) {
        const dist = km(live, order.dest);
        el.textContent = t("live.near", { dist: distText(dist), eta: etaText(dist), ago: ago(live.t) });
      } else el.textContent = t("live.loc", { ago: ago(live.t) });
    } else el.textContent = t("live.noloc");
  } else if (s === "packed") el.textContent = t("live.packed");
  else el.textContent = t("live.received");
}

$("#f").addEventListener("submit", (e) => { e.preventDefault(); start($("#code").value); });
setInterval(liveLine, 15000);

relang();
const initial = new URLSearchParams(location.search).get("c");
if (initial) start(initial);
