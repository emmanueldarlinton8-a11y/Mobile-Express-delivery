import { firebaseConfig } from "./firebase-config.js";

// One small data layer, two backends:
//  - Firebase (real, shared between phones) when firebase-config.js is filled in
//  - Demo mode (this browser only) otherwise, so you can try everything first

export async function init() {
  if (firebaseConfig && firebaseConfig.apiKey) return firebaseImpl(firebaseConfig);
  return demoImpl();
}

async function firebaseImpl(cfg) {
  const base = "https://www.gstatic.com/firebasejs/10.14.1/";
  const [{ initializeApp }, A, F] = await Promise.all([
    import(base + "firebase-app.js"),
    import(base + "firebase-auth.js"),
    import(base + "firebase-firestore.js"),
  ]);
  const app = initializeApp(cfg);
  const auth = A.getAuth(app);
  const db = F.getFirestore(app);
  const ref = (c, id) => F.doc(db, c, id);
  return {
    mode: "firebase",
    onAuth(cb) {
      return A.onAuthStateChanged(auth, async (u) => {
        if (!u) return cb(null, null);
        let role = null;
        try { const s = await F.getDoc(ref("staff", u.uid)); role = s.exists() ? s.data().role : null; } catch (e) { /* no access */ }
        cb(u, role);
      });
    },
    login: (email, pw) => A.signInWithEmailAndPassword(auth, email, pw),
    logout: () => A.signOut(auth),
    watchOrder: (code, cb) => F.onSnapshot(ref("orders", code), (s) => cb(s.exists() ? s.data() : null), () => cb(null)),
    watchLive: (code, cb) => F.onSnapshot(ref("live", code), (s) => cb(s.exists() ? s.data() : null), () => cb(null)),
    watchOrders: (cb) =>
      F.onSnapshot(F.query(F.collection(db, "orders"), F.orderBy("updatedAt", "desc"), F.limit(300)), (s) => cb(s.docs.map((d) => d.data()))),
    async getContact(code) { const s = await F.getDoc(ref("contacts", code)); return s.exists() ? s.data() : {}; },
    async saveOrder(code, pub, contact) {
      await F.setDoc(ref("orders", code), pub);
      await F.setDoc(ref("contacts", code), contact);
    },
    patchOrder: (code, patch) => F.setDoc(ref("orders", code), patch, { merge: true }),
    setLive: (code, loc) => F.setDoc(ref("live", code), loc),
    clearLive: (code) => F.deleteDoc(ref("live", code)),
    async deleteOrder(code) {
      await F.deleteDoc(ref("orders", code));
      await F.deleteDoc(ref("contacts", code));
      await F.deleteDoc(ref("live", code));
    },
  };
}

function demoImpl() {
  const K = "mex_demo_";
  const read = (k, d) => { try { return JSON.parse(localStorage.getItem(K + k)) ?? d; } catch { return d; } };
  const write = (k, v) => localStorage.setItem(K + k, JSON.stringify(v));
  const subs = new Set();
  const fire = () => subs.forEach((f) => f());
  addEventListener("storage", (e) => { if (e.key && e.key.startsWith(K)) fire(); });
  const watch = (fn) => { subs.add(fn); fn(); return () => subs.delete(fn); };

  if (!Object.keys(read("orders", {})).length) {
    const now = Date.now();
    write("orders", {
      "MEX-DEMO2026": {
        code: "MEX-DEMO2026", recipient: "Ada M.", items: "iPhone 15 Pro 256GB x1, 20W fast charger x1",
        status: "out", total: 8500, paid: 4250, payment: "part",
        dest: { lat: 14.5995, lng: -90.5133, label: "Zona 10, Ciudad de Guatemala" }, area: "Zona 4, Ciudad de Guatemala", eta: "Today, before 5 PM", rider: "Carlos",
        timeline: [
          { status: "received", note: "Order created", at: now - 7200000 },
          { status: "packed", note: "Packed and tested", at: now - 3600000 },
          { status: "out", note: "Rider is on the way", at: now - 600000 },
        ],
        createdAt: now - 7200000, updatedAt: now - 600000,
      },
    });
    write("contacts", { "MEX-DEMO2026": { fullName: "Ada Morales", phone: "5551 2345", address: "12 Avenida 5-30, Zona 10" } });
  }

  return {
    mode: "demo",
    onAuth(cb) {
      const go = () => { const u = read("user", null); cb(u, u ? "admin" : null); };
      go();
      subs.add(go);
      return () => subs.delete(go);
    },
    async login(email) { write("user", { email, uid: "demo" }); fire(); },
    async logout() { localStorage.removeItem(K + "user"); fire(); },
    watchOrder: (code, cb) => watch(() => cb(read("orders", {})[code] || null)),
    watchLive: (code, cb) => watch(() => cb(read("live", {})[code] || null)),
    watchOrders: (cb) => watch(() => cb(Object.values(read("orders", {})).sort((a, b) => b.updatedAt - a.updatedAt))),
    async getContact(code) { return read("contacts", {})[code] || {}; },
    async saveOrder(code, pub, contact) {
      const o = read("orders", {}); o[code] = pub; write("orders", o);
      const c = read("contacts", {}); c[code] = contact; write("contacts", c);
      fire();
    },
    async patchOrder(code, patch) {
      const o = read("orders", {}); o[code] = { ...(o[code] || {}), ...patch }; write("orders", o); fire();
    },
    async setLive(code, loc) { const l = read("live", {}); l[code] = loc; write("live", l); fire(); },
    async clearLive(code) { const l = read("live", {}); delete l[code]; write("live", l); fire(); },
    async deleteOrder(code) {
      for (const k of ["orders", "contacts", "live"]) { const o = read(k, {}); delete o[code]; write(k, o); }
      fire();
    },
  };
}
