import { init } from "./db.js";
import { $, STATUS_LABEL, PAY, money, esc, toast } from "./common.js";

const api = await init();
if (api.mode === "demo") { $("#demo").hidden = false; $("#sim").hidden = false; }

let orders = [], selected = new Set(), contacts = {}, started = false;
let watchId = null, lastPush = 0, wake = null, simTimer = null;

/* ---------- auth ---------- */
api.onAuth((user, role) => {
  if (!user) { $("#login").hidden = false; $("#app").hidden = true; $("#logout").hidden = true; return; }
  if (role !== "rider" && role !== "admin") {
    $("#login").hidden = false; $("#app").hidden = true;
    const m = $("#lmsg"); m.hidden = false; m.textContent = "This account is not set up as a rider. See README.md, step 4.";
    return;
  }
  $("#login").hidden = true; $("#app").hidden = false; $("#logout").hidden = false;
  if (!started) { started = true; api.watchOrders((list) => { orders = list.filter((o) => o.status === "packed" || o.status === "out"); render(); }); }
});
$("#lf").addEventListener("submit", async (e) => {
  e.preventDefault(); $("#lmsg").hidden = true;
  try { await api.login($("#em").value.trim(), $("#pw").value); }
  catch (err) { const m = $("#lmsg"); m.hidden = false; m.textContent = "Could not log in. Check your email and password."; }
});
$("#logout").addEventListener("click", () => { stopSharing(); api.logout(); });

/* ---------- list ---------- */
async function loadContact(code) {
  if (contacts[code]) return;
  try { contacts[code] = await api.getContact(code); } catch (e) { contacts[code] = {}; }
  render();
}

function render() {
  for (const code of [...selected]) if (!orders.find((o) => o.code === code)) selected.delete(code);
  $("#list").innerHTML = orders.length
    ? orders.map((o) => {
        const c = contacts[o.code];
        if (!c) loadContact(o.code);
        const bal = Math.max(0, (o.total || 0) - (o.paid || 0));
        const phone = c?.phone ? `<a href="tel:${esc(c.phone)}">${esc(c.phone)}</a>` : "";
        return `<li class="card stack">
          <label class="row" style="flex-direction:row;align-items:center;color:var(--fg);font-size:1rem">
            <input type="checkbox" data-sel="${esc(o.code)}" style="width:22px;height:22px" ${selected.has(o.code) ? "checked" : ""}>
            <b style="font-family:var(--display);letter-spacing:.05em">${esc(o.code)}</b>
            <span class="pill ${o.status}">${STATUS_LABEL[o.status]}</span>
          </label>
          <div><b>${esc(c?.fullName || o.recipient)}</b> ${phone ? "&middot; " + phone : ""}</div>
          <div class="mut">${esc(c?.address || o.dest?.label || "Address not set")}</div>
          <div>${esc(o.items)}</div>
          <div class="row"><span class="pill ${o.payment}">${PAY[o.payment]}</span>${bal ? `<span>Collect balance: <b>${money(bal)}</b></span>` : ""}</div>
          <button class="ghost" data-done="${esc(o.code)}">Mark delivered</button>
        </li>`;
      }).join("")
    : `<li class="card mut">No orders to deliver right now.</li>`;
}

$("#list").addEventListener("change", (e) => {
  const c = e.target.dataset.sel; if (!c) return;
  e.target.checked ? selected.add(c) : selected.delete(c);
});
$("#list").addEventListener("click", async (e) => {
  const code = e.target.dataset.done; if (!code) return;
  const o = orders.find((x) => x.code === code); if (!o) return;
  try {
    await api.patchOrder(code, {
      status: "delivered", updatedAt: Date.now(),
      timeline: [...(o.timeline || []), { status: "delivered", note: "Delivered to recipient", at: Date.now() }],
    });
    await api.clearLive(code);
    selected.delete(code); toast("Marked as delivered");
  } catch (err) { toast("Could not update. Check your connection."); }
});

/* ---------- live location ---------- */
function say(msg) { const s = $("#status"); s.hidden = !msg; s.textContent = msg || ""; }

async function push(lat, lng, extra = {}) {
  const now = Date.now();
  if (now - lastPush < 6000) return;
  lastPush = now;
  const loc = { lat, lng, t: now, ...extra };
  for (const code of selected) { try { await api.setLive(code, loc); } catch (e) { /* retry next tick */ } }
  say(`Sharing live location with ${selected.size} order${selected.size === 1 ? "" : "s"}. Last sent ${new Date(now).toLocaleTimeString("en-NG", { hour: "numeric", minute: "2-digit", second: "2-digit" })}.`);
}

async function markOut() {
  for (const code of selected) {
    const o = orders.find((x) => x.code === code);
    if (o && o.status !== "out") {
      await api.patchOrder(code, {
        status: "out", updatedAt: Date.now(),
        timeline: [...(o.timeline || []), { status: "out", note: "Rider is on the way", at: Date.now() }],
      });
    }
  }
}

function setSharing(on) { $("#go").hidden = on; $("#stop").hidden = !on; if (!on) say(""); }

$("#go").addEventListener("click", async () => {
  if (!selected.size) return toast("Tick at least one order first");
  if (!navigator.geolocation) return toast("This phone cannot share location");
  try { await markOut(); } catch (e) { return toast("Could not start. Check your connection."); }
  lastPush = 0; setSharing(true); say("Getting your location…");
  try { wake = await navigator.wakeLock?.request("screen"); } catch (e) { wake = null; }
  watchId = navigator.geolocation.watchPosition(
    (p) => push(+p.coords.latitude.toFixed(6), +p.coords.longitude.toFixed(6), { heading: p.coords.heading ?? null, speed: p.coords.speed ?? null }),
    (err) => { say(err.code === 1 ? "Location is blocked. Allow location for this site in your browser settings." : "Waiting for GPS signal…"); },
    { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 }
  );
});

function stopSharing() {
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  watchId = null;
  if (simTimer) clearInterval(simTimer);
  simTimer = null;
  try { wake?.release(); } catch (e) { /* ignore */ }
  wake = null;
  setSharing(false);
}
$("#stop").addEventListener("click", stopSharing);

/* demo only: move a fake rider toward each selected drop-off pin */
$("#sim").addEventListener("click", async () => {
  if (!selected.size) return toast("Tick at least one order first");
  await markOut();
  setSharing(true); lastPush = 0;
  let step = 0; const total = 40;
  simTimer = setInterval(async () => {
    step++;
    for (const code of selected) {
      const o = orders.find((x) => x.code === code);
      const d = o?.dest; if (!d) continue;
      const k = 1 - step / total;
      await api.setLive(code, { lat: d.lat + 0.03 * k, lng: d.lng - 0.03 * k, t: Date.now(), heading: null, speed: null });
    }
    say(`Simulated drive, step ${step} of ${total}.`);
    if (step >= total) stopSharing();
  }, 1500);
});
