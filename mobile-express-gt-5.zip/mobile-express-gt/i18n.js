// Customer-page translations. To add a language: copy one block, translate it,
// and add it to LANGS and LOCALES. Missing keys fall back to English.
const DICT = {
  en: {
    "doc.title": "Track Your Order | Mobile Express GT",
    tagline: "Technology at your fingertips",
    lang: "Language",
    demo: "Demo mode: data is stored in this browser only. Try code {code}. See README.md to go live.",
    "hero.h1": "Where is my order?",
    "hero.p": "Enter the tracking code we sent you to see your goods, payment and the rider's live location.",
    "hero.btn": "Track order",
    "hero.alt": "Mobile Express GT neon shop sign",
    "msg.looking": "Looking up your order…",
    "msg.notfound": "We could not find an order with that code. Check it and try again.",
    "res.code": "Tracking code",
    "res.order": "Your order",
    "res.updates": "Updates",
    "k.recipient": "Recipient", "k.goods": "Goods", "k.total": "Total", "k.paid": "Paid", "k.balance": "Balance",
    "k.none": "None", "k.payment": "Payment", "k.rider": "Rider", "k.area": "Last known area", "k.expected": "Expected",
    "status.received": "Order received", "status.packed": "Packed", "status.out": "Out for delivery", "status.delivered": "Delivered", "status.cancelled": "Cancelled",
    "pay.unpaid": "Unpaid", "pay.part": "Part paid", "pay.paid": "Paid in full",
    "live.delivered": "Delivered. Thank you for choosing Mobile Express GT.",
    "live.cancelled": "This order was cancelled. Please contact us for help.",
    "live.near": "Rider is about {dist} away (roughly {eta}). Updated {ago}.",
    "live.loc": "Rider location updated {ago}.",
    "live.noloc": "Your rider is on the way. The live location will show here shortly.",
    "live.packed": "Your goods are packed and waiting for dispatch.",
    "live.received": "We have received your order and are preparing it.",
    "map.rider": "Rider", "map.dest": "Drop-off",
    "note.created": "Order created", "note.onway": "Rider is on the way", "note.delivered": "Delivered to recipient", "note.packedtested": "Packed and tested",
    "ago.never": "never", "ago.s": "{n}s ago", "ago.m": "{n} min ago", "ago.h": "{n} hr ago", "ago.d": "{n} d ago",
    "eta.min": "{n} min", "eta.hrmin": "{h} hr {m} min",
  },
  es: {
    "doc.title": "Rastrea tu pedido | Mobile Express GT",
    tagline: "Tecnología al alcance de tu mano",
    lang: "Idioma",
    demo: "Modo demostración: los datos se guardan solo en este navegador. Prueba el código {code}. Lee el README.md para publicarlo.",
    "hero.h1": "¿Dónde está mi pedido?",
    "hero.p": "Ingresa el código de seguimiento que te enviamos para ver tus productos, el pago y la ubicación del repartidor en vivo.",
    "hero.btn": "Rastrear pedido",
    "hero.alt": "Letrero de neón de Mobile Express GT",
    "msg.looking": "Buscando tu pedido…",
    "msg.notfound": "No encontramos un pedido con ese código. Revísalo e inténtalo de nuevo.",
    "res.code": "Código de seguimiento",
    "res.order": "Tu pedido",
    "res.updates": "Novedades",
    "k.recipient": "Destinatario", "k.goods": "Productos", "k.total": "Total", "k.paid": "Pagado", "k.balance": "Saldo",
    "k.none": "Ninguno", "k.payment": "Pago", "k.rider": "Repartidor", "k.area": "Última zona conocida", "k.expected": "Entrega estimada",
    "status.received": "Pedido recibido", "status.packed": "Empacado", "status.out": "En camino", "status.delivered": "Entregado", "status.cancelled": "Cancelado",
    "pay.unpaid": "Sin pagar", "pay.part": "Pago parcial", "pay.paid": "Pagado completo",
    "live.delivered": "Entregado. Gracias por elegir Mobile Express GT.",
    "live.cancelled": "Este pedido fue cancelado. Contáctanos para recibir ayuda.",
    "live.near": "El repartidor está a unos {dist} (aprox. {eta}). Actualizado {ago}.",
    "live.loc": "Ubicación del repartidor actualizada {ago}.",
    "live.noloc": "Tu repartidor va en camino. La ubicación en vivo aparecerá aquí en breve.",
    "live.packed": "Tus productos están empacados y esperan salir.",
    "live.received": "Recibimos tu pedido y lo estamos preparando.",
    "map.rider": "Repartidor", "map.dest": "Punto de entrega",
    "note.created": "Pedido creado", "note.onway": "El repartidor va en camino", "note.delivered": "Entregado al destinatario", "note.packedtested": "Empacado y probado",
    "ago.never": "nunca", "ago.s": "hace {n} s", "ago.m": "hace {n} min", "ago.h": "hace {n} h", "ago.d": "hace {n} d",
    "eta.min": "{n} min", "eta.hrmin": "{h} h {m} min",
  },
  fr: {
    "doc.title": "Suivre ma commande | Mobile Express GT",
    tagline: "La technologie au bout des doigts",
    lang: "Langue",
    demo: "Mode démo : les données restent dans ce navigateur. Essayez le code {code}. Voir README.md pour la mise en ligne.",
    "hero.h1": "Où est ma commande ?",
    "hero.p": "Saisissez le code de suivi que nous vous avons envoyé pour voir vos articles, le paiement et la position du livreur en direct.",
    "hero.btn": "Suivre la commande",
    "hero.alt": "Enseigne néon Mobile Express GT",
    "msg.looking": "Recherche de votre commande…",
    "msg.notfound": "Aucune commande trouvée avec ce code. Vérifiez-le et réessayez.",
    "res.code": "Code de suivi",
    "res.order": "Votre commande",
    "res.updates": "Mises à jour",
    "k.recipient": "Destinataire", "k.goods": "Articles", "k.total": "Total", "k.paid": "Payé", "k.balance": "Solde",
    "k.none": "Aucun", "k.payment": "Paiement", "k.rider": "Livreur", "k.area": "Dernière zone connue", "k.expected": "Livraison prévue",
    "status.received": "Commande reçue", "status.packed": "Préparée", "status.out": "En cours de livraison", "status.delivered": "Livrée", "status.cancelled": "Annulée",
    "pay.unpaid": "Non payée", "pay.part": "Paiement partiel", "pay.paid": "Payée en totalité",
    "live.delivered": "Livrée. Merci d'avoir choisi Mobile Express GT.",
    "live.cancelled": "Cette commande a été annulée. Contactez-nous pour obtenir de l'aide.",
    "live.near": "Le livreur est à environ {dist} (environ {eta}). Mis à jour {ago}.",
    "live.loc": "Position du livreur mise à jour {ago}.",
    "live.noloc": "Votre livreur est en route. La position en direct s'affichera ici sous peu.",
    "live.packed": "Vos articles sont préparés et attendent le départ.",
    "live.received": "Nous avons reçu votre commande et la préparons.",
    "map.rider": "Livreur", "map.dest": "Point de livraison",
    "note.created": "Commande créée", "note.onway": "Le livreur est en route", "note.delivered": "Livré au destinataire", "note.packedtested": "Préparé et testé",
    "ago.never": "jamais", "ago.s": "il y a {n} s", "ago.m": "il y a {n} min", "ago.h": "il y a {n} h", "ago.d": "il y a {n} j",
    "eta.min": "{n} min", "eta.hrmin": "{h} h {m} min",
  },
  pt: {
    "doc.title": "Rastreie seu pedido | Mobile Express GT",
    tagline: "Tecnologia na ponta dos dedos",
    lang: "Idioma",
    demo: "Modo demonstração: os dados ficam só neste navegador. Teste o código {code}. Veja o README.md para publicar.",
    "hero.h1": "Onde está o meu pedido?",
    "hero.p": "Digite o código de rastreamento que enviamos para ver seus produtos, o pagamento e a localização do entregador ao vivo.",
    "hero.btn": "Rastrear pedido",
    "hero.alt": "Letreiro de neon da Mobile Express GT",
    "msg.looking": "Procurando o seu pedido…",
    "msg.notfound": "Não encontramos nenhum pedido com esse código. Confira e tente novamente.",
    "res.code": "Código de rastreamento",
    "res.order": "Seu pedido",
    "res.updates": "Atualizações",
    "k.recipient": "Destinatário", "k.goods": "Produtos", "k.total": "Total", "k.paid": "Pago", "k.balance": "Saldo",
    "k.none": "Nenhum", "k.payment": "Pagamento", "k.rider": "Entregador", "k.area": "Última área conhecida", "k.expected": "Previsão",
    "status.received": "Pedido recebido", "status.packed": "Embalado", "status.out": "Saiu para entrega", "status.delivered": "Entregue", "status.cancelled": "Cancelado",
    "pay.unpaid": "Não pago", "pay.part": "Pago parcialmente", "pay.paid": "Pago integralmente",
    "live.delivered": "Entregue. Obrigado por escolher a Mobile Express GT.",
    "live.cancelled": "Este pedido foi cancelado. Entre em contato conosco para ajuda.",
    "live.near": "O entregador está a cerca de {dist} (aprox. {eta}). Atualizado {ago}.",
    "live.loc": "Localização do entregador atualizada {ago}.",
    "live.noloc": "Seu entregador está a caminho. A localização ao vivo aparecerá aqui em breve.",
    "live.packed": "Seus produtos estão embalados e aguardando a saída.",
    "live.received": "Recebemos seu pedido e estamos preparando.",
    "map.rider": "Entregador", "map.dest": "Ponto de entrega",
    "note.created": "Pedido criado", "note.onway": "O entregador está a caminho", "note.delivered": "Entregue ao destinatário", "note.packedtested": "Embalado e testado",
    "ago.never": "nunca", "ago.s": "há {n} s", "ago.m": "há {n} min", "ago.h": "há {n} h", "ago.d": "há {n} d",
    "eta.min": "{n} min", "eta.hrmin": "{h} h {m} min",
  },
};

export const LANGS = [["es", "Español"], ["en", "English"], ["fr", "Français"], ["pt", "Português"]];
const LOCALES = { en: "en-US", es: "es-GT", fr: "fr-FR", pt: "pt-BR" };

let lang = "en"; // admin and rider pages stay in English; the customer page calls initLang()

export const getLang = () => lang;
export const locale = () => LOCALES[lang];

export function initLang() {
  let l = null;
  try { l = localStorage.getItem("mex_lang"); } catch (e) { /* ignore */ }
  if (!DICT[l]) {
    const n = (navigator.language || "").slice(0, 2).toLowerCase();
    l = DICT[n] ? n : "es";
  }
  setLang(l, false);
  return l;
}

export function setLang(l, save = true) {
  if (!DICT[l]) return;
  lang = l;
  document.documentElement.lang = l;
  if (save) { try { localStorage.setItem("mex_lang", l); } catch (e) { /* ignore */ } }
}

export function t(key, vars) {
  let s = DICT[lang]?.[key] ?? DICT.en[key] ?? key;
  if (vars) for (const k of Object.keys(vars)) s = s.replaceAll("{" + k + "}", vars[k]);
  return s;
}

// Notes the apps write by default are stored in English; show them in the viewer's language.
const NOTE_KEYS = {
  "Order created": "note.created", "Rider is on the way": "note.onway",
  "Delivered to recipient": "note.delivered", "Packed and tested": "note.packedtested",
  "Order received": "status.received", "Packed": "status.packed", "Out for delivery": "status.out",
  "Delivered": "status.delivered", "Cancelled": "status.cancelled",
};
export const noteText = (note) => (NOTE_KEYS[note] ? t(NOTE_KEYS[note]) : note);

export function applyStatic() {
  document.querySelectorAll("[data-i18n]").forEach((el) => (el.textContent = t(el.dataset.i18n)));
  document.querySelectorAll("[data-i18n-alt]").forEach((el) => (el.alt = t(el.dataset.i18nAlt)));
  document.title = t("doc.title");
}
